//
//  MovieCell.swift
//  MeganBacani-Lab4
//
//  Created by Megan Bacani on 3/6/17.
//  Copyright © 2017 Megan Bacani. All rights reserved.
//

import UIKit

class MovieCell: UICollectionViewCell {

    @IBOutlet weak var moviePoster: UIImageView!
    
    @IBOutlet weak var movieTitle: UILabel!
    
    
}
