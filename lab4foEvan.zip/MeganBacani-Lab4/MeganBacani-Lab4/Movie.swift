//
//  Movie.swift
//  MeganBacani-Lab4
//
//  Created by Megan Bacani on 3/5/17.
//  Copyright © 2017 Megan Bacani. All rights reserved.
//
import UIKit

class Movie {
    var title: String
    var year: String
    var id: String
    var type: String
    var poster: UIImage
    
    init(title: String, year: String, id: String, type: String, poster: UIImage){
        self.title = title
        self.year = year
        self.id = id
        self.type = type
        self.poster = poster
    }
}
