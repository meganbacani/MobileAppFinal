//
//  FirstViewController.swift
//  MeganBacani-Lab4
//
//  Created by Megan Bacani on 3/5/17.
//  Copyright © 2017 Megan Bacani. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource, UISearchBarDelegate {
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var activitySpin: UIActivityIndicatorView!

    
    var moviesArray:[Movie] = []
    var imageCache: [UIImage] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        self.searchBar.delegate = self
        print(fetchDataForCollectionView("Batman"))
        for element in moviesArray{
            print(element.title)
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func fetchJSON(_ url: String) -> JSON{
               if let url = URL(string: url){
            if let data = try? Data(contentsOf: url) {
                let json = JSON(data: data)
                return json
            } else {
                return JSON.null
            }
        } else {
            return JSON.null
        }
        
    
    }
    
    private func fetchDataForCollectionView(_ searchString: String) {
        
        var json = JSON({})
        var json2 = JSON({})
     
        let spin = UIActivityIndicatorView(activityIndicatorStyle: .gray)
        spin.center = view.center
        view.addSubview(spin)
        spin.startAnimating()

        DispatchQueue.global(qos: .background).async { [weak self]
            () -> Void in
            let url = "http://www.omdbapi.com/?s=" + searchString + "&page=1"
            print(url)
            json = (self?.fetchJSON(url))!
        
            let url2 = "http://www.omdbapi.com/?s=" + searchString + "&page=2"
            print(url2)
            json2 = (self?.fetchJSON(url2))!

            DispatchQueue.main.async {
                () -> Void in
                for result in json["Search"] {

                    let movie = result.1
                    let title = movie["Title"].stringValue
                    let year = movie["Year"].stringValue
                    let id = movie["imdbID"].stringValue
                    let type = movie["Type"].stringValue
                    
                    let posterUrl = URL(string: movie["Poster"].stringValue)
                    let data = try? Data(contentsOf: posterUrl!)
                    let poster = UIImage(data: data!)
                    self?.moviesArray.append(Movie(title: title, year: year, id: id, type: type, poster: poster!))
                    
                }
                
                for result in json2["Search"] {
                    let movie = result.1
                    let title = movie["Title"].stringValue
                    let year = movie["Year"].stringValue
                    let id = movie["imdbID"].stringValue
                    let type = movie["Type"].stringValue
                    
                    let posterUrl = URL(string: movie["Poster"].stringValue)
                    let data = try? Data(contentsOf: posterUrl!)
                    //FIXME plz for when there is no image
                    let poster = UIImage(data: data!)
                    self?.moviesArray.append(Movie(title: title, year: year, id: id, type: type, poster: poster!))
                    
                }
                    self?.collectionView.reloadData()
                    self?.view.subviews[(self?.view.subviews.count)!-1].removeFromSuperview()

            }
         }
       
        
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return moviesArray.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell:  MovieCell = collectionView.dequeueReusableCell(withReuseIdentifier: "mCell", for: indexPath as IndexPath) as! MovieCell
   
        cell.movieTitle!.text = moviesArray[indexPath.row].title
        cell.moviePoster?.image = moviesArray[indexPath.row].poster
        
        return cell
    }
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        view.endEditing(true)
        print(searchBar.text!)
        moviesArray.removeAll()
       fetchDataForCollectionView(searchBar.text!)
    }


}

